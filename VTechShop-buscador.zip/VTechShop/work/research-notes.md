# Investigación de diseño VTechShop

Inicio: 2026-11-19 12:34:08 UTC. No comenzar implementación visual antes de 13:14:08 UTC.

## Alcance
Rediseño local de la aplicación PHP existente y README. Conservar operaciones, nombres de endpoints y datos de MySQL. Sin contenido de relleno, promociones inventadas ni servicios inexistentes.

## Primera observación
Teenage Engineering: imágenes sobre campos neutros, cuadrícula generosa, detalles mínimos y botón de adición cerca del precio. Aplicar jerarquía y espacio, sin copiar su marca ni promociones.

## Framework Marketplace
URL: https://frame.work/marketplace
Observación visual: navegación lateral por categorías con recuentos y selección persistente, rejilla de tres tarjetas, fotografías sobre fondos de color controlado, tipografía sobria, precio cercano al título. Interesa la navegación explícita; descartar filtros que no existan en VTechShop.

## Nothing
URL: https://us.nothing.tech/
Observación: fotografía dominante, tipografía con personalidad y controles pequeños sobre un marco sobrio. La portada editorial es útil para identidad; no reproducir campañas, descuentos, logística, comunidad o newsletter porque VTechShop no los implementa. Evitar también modales de región y marketing que bloquean el contenido.

## Restricciones de contenido detectadas
El checkout actual solo registra pedidos, no integra pasarela: el botón debe describir confirmación, sin prometer pago online. Las monedas solo cambian símbolo, sin cambio de divisas: el README debe documentarlo. Recomendaciones ya proporcionan motivos y compatibilidad parcial; conservar la lógica y no aumentar las garantías en los textos.

## Observaciones de fichas y accesibilidad
Fractal North: imágenes amplias, especificaciones separadas de la descripción, cabecera pequeña. Wooting: acción principal consistente, secciones técnicas claras. Teenage Engineering móvil: jerarquía de una pieza dominante y tarjetas menores; no trasladar su tipografía pequeña ni controles sin texto a acciones críticas.
Fuentes: https://www.fractal-design.com/products/cases/north/north/ ; https://wooting.io/wooting-80he-plus ; https://teenage.engineering/store

## Interacciones
W3C APG combobox: conservar escritura estándar, cerrar con Escape y navegar sugerencias con teclado. Etiquetas asociadas explícitamente. Reducir movimiento según preferencia del sistema. Controles táctiles cómodos, foco visible. No bloquear catálogo con animaciones ni puertas de consentimiento copiadas de referencias.
Fuentes: https://www.w3.org/WAI/ARIA/apg/patterns/combobox/ ; https://www.w3.org/WAI/tutorials/forms/labels/ ; https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html

## Carrito
Baymard: cambios de cantidad claros, resumen actualizado tras cambio, controles separados suficientemente en móvil. Mantener el POST existente y mejorar la respuesta visual, sin reescribir el checkout.
Fuente: https://baymard.com/research-articles/auto-update-users-quantity-changes

## Segunda mitad de la investigación
Comparados catálogos móvil y escritorio de Framework y Teenage Engineering, la ficha de Fractal North, las presentaciones de Wooting y el enfoque editorial de Doron Supply. Revisadas las galerías de Awwwards (E-Commerce y Solara Halo S1) y Ecommerce Design Awards (Technology), más navegación de PCComponentes, Scan y Corsair.

Decisiones de contenido: una portada compacta con acceso al catálogo; no carruseles automáticos, testimonios inventados, newsletter sin servicio, financiación ni descuentos. Los vacíos tendrán acción concreta para continuar. Imágenes faltantes se cubrirán con ilustraciones originales de categoría identificables como tales, sin atribuir una fotografía a un modelo distinto.

Decisiones de documentación: instalación local PHP/MySQL, orden de los SQL y advertencia del DROP DATABASE existente; cookies cart (30 días) y vtech_history (30 días / 12 productos); compras sin pasarela; recomendación con afinidad de categorías, socket, tipo de memoria, precio relativo y popularidad. Documentar límites de compatibilidad y moneda con honestidad.

## Comparación con la aplicación actual
La versión sin CSS ya funciona con 146 productos y 12 categorías en una base temporal. El menú muestra categorías; recomendaciones y catálogo comparten la misma tarjeta y hoy no se distinguen visualmente. El carrito usa controles POST existentes, y la búsqueda devuelve hasta ocho coincidencias. El diseño conservará estos contratos.

## Criterios para la intervención
- Mantener helpers y reglas de negocio; concentrar el trabajo en vistas, CSS, recursos y JS de interacción.
- No introducir un framework ni una compilación para una aplicación PHP sencilla.
- No inventar evaluaciones, descuentos, financiación, garantías, tiempos de entrega ni enlaces a redes sin contenido.
- Añadir solo navegación útil, jerarquía de datos reales, estados vacíos y feedback de acciones existentes.
- README con capturas reales, arquitectura, instalación, API, cookies y límites conocidos.

## Contraste y tipografía
Evaluados fondos claros fríos y grafito, con acento naranja como recurso de orientación. Contraste calculado: grafito #17191B sobre #F4F5F3 = 16.12:1; blanco sobre grafito = 17.63:1; grafito sobre naranja #FF6B35 = 6.22:1. No usar blanco pequeño sobre naranja. Fuentes evaluadas: Barlow Condensed para titulares y Manrope para lectura, con licencias OFL verificadas en el repositorio oficial de Google Fonts. Se alojarán localmente.

## Alcance técnico de la documentación
La estructura SQL base no crea aún socket, memory_type y category_affinity que requiere helpers/recommendations.php. Añadir un script de preparación separado y documentar su ejecución, sin importar ni modificar la base real del usuario. La reproducción y capturas usarán un MariaDB temporal en /tmp, sin red, con 146 productos y 12 categorías.

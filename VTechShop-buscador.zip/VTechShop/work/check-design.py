import urllib.request, urllib.parse, urllib.error, http.cookiejar, json, re, subprocess, uuid
base='http://127.0.0.1:8088/'
jar=http.cookiejar.CookieJar(); client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def request(path,data=None,json_body=None):
 headers={};body=None
 if data is not None:body=urllib.parse.urlencode(data).encode()
 if json_body is not None:body=json.dumps(json_body).encode();headers['Content-Type']='application/json'
 try:r=client.open(urllib.request.Request(base+path,body,headers))
 except urllib.error.HTTPError as ex:r=ex
 content=r.read().decode();assert not re.search(r'(Warning:|Fatal error:|Uncaught)',content),content[:1000]
 return r.status,content,r.url
def sql(code):
 r=subprocess.run(['/Applications/XAMPP/xamppfiles/bin/php','-c','/tmp/vtechshop-design-php.ini','-r','require "config/connection.php"; '+code],capture_output=True,text=True,check=True)
 assert not r.stderr,r.stderr
 return r.stdout
for path in ['index.php','index.php?cat=1','products.php?id=2','cart.php','auth/auth-page.php','assets/css/style.css','assets/js/app.js','assets/illustrations/cpu.svg']:
 assert request(path)[0]==200
 print('PASS',path)
status,data,_=request('search-ajax.php?q=Ryzen');assert len(json.loads(data))>0;print('PASS búsqueda AJAX')
_,data,_=request('cart-api.php',json_body={'action':'add','product_id':2,'quantity':2});assert json.loads(data)['success'];print('PASS añadir al carrito AJAX')
_,body,_=request('cart.php');assert 'Ryzen 5 7600' in body and 'quantity-controls' in body;print('PASS carrito y cantidad')
request('cart.php',{'action':'update','product_id':2,'quantity':1});print('PASS actualizar carrito')
tag='design_'+uuid.uuid4().hex[:10];email=tag+'@example.test'
_,body,url=request('auth/auth-process.php',{'action':'register','username':tag,'email':email,'password':'DemoPass123!','confirm_password':'DemoPass123!','currency':'EUR','redirect':'checkout'})
assert 'checkout.php' in url and 'Dirección de envío' in body;print('PASS registro y redirección al checkout')
uid=int(sql('$s=$conn->prepare("SELECT user_id FROM users WHERE email=?");$s->execute(["'+email+'"]);echo $s->fetchColumn();'))
before=int(sql('echo $conn->query("SELECT stock FROM products WHERE products_id=2")->fetchColumn();'))
_,body,url=request('checkout.php',{'shipping_address':'Calle de Prueba 123, 35001 Las Palmas'})
assert 'orders.php' in url and 'registrado correctamente' in body;print('PASS pedido e historial')
after=int(sql('echo $conn->query("SELECT stock FROM products WHERE products_id=2")->fetchColumn();'));assert after==before-1;print('PASS descuento de stock')
request('auth/auth-process.php',{'action':'logout'});_,body,_=request('auth/auth-page.php');assert 'auth-form-panel' in body;print('PASS logout')
_,body,url=request('auth/auth-process.php',{'action':'login','email':email,'password':'bad'});assert 'incorrectas' in body;print('PASS error de login')
_,body,url=request('auth/auth-process.php',{'action':'login','email':email,'password':'DemoPass123!'});assert 'index.php' in url;print('PASS login')
_,body,_=request('orders.php');assert 'Pedido #' in body;print('PASS historial de la cuenta')
# Retain only this test account in the disposable DB for screenshots. Never touch the user's DB.
from pathlib import Path
Path('/tmp/vtechshop-design-fixture.json').write_text(json.dumps({'user':tag,'email':email,'password':'DemoPass123!'}))
print('Pruebas completadas en la base temporal.')

import concurrent.futures, io, json, re, sys, unicodedata, urllib.request
from pathlib import Path
sys.path.insert(0, '/tmp/vtech-image-libs')
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/products'
OUT.mkdir(parents=True, exist_ok=True)
RAW = ROOT / 'work/product-originals'
RAW.mkdir(parents=True, exist_ok=True)

def norm(s):
    return re.sub(r'[^a-z0-9]+', ' ', unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()).strip()

def score(p, c):
    title = c['text'].split('Image URL:')[0]
    text = norm(title + ' ' + c['image'])
    model = norm(p['model'])
    tokens = set(model.split()) - {'mt', 's', 'mhz', '2x16gb', '2x32gb', 'black', 'white', 'gaming', 'wireless', 'rgb', 'gb'}
    points = 0
    for t in tokens:
        weight = 6 if any(ch.isdigit() for ch in t) else 2
        points += weight if re.search(r'\b' + re.escape(t) + r'\b', text) else -weight * 1.5
    # Prefer ordinary catalog photos over review shots, marketplaces and collages.
    if any(x in text for x in ['review', 'benchmark', 'vs ', 'unboxing', 'shopee', 'aliexpress', 'used ', '中古']): points -= 12
    if any(x in c['image'] for x in ['storage-asset.msi', 'dlcdnwebimgs.asus', 'assets.corsair', 'logitech', 'media.ldlc', 'ibertronica', 'images.samsung']): points += 7
    if 'white background' in c['text'].lower(): points += 3
    return points

def fetch(c):
    url = c['image']
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=12) as r: data = r.read(20000000)
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))
    if min(im.size) < 200: raise ValueError('small image')
    rgba = im.convert('RGBA')
    w,h = rgba.size
    points = [(int(w*x),int(h*y)) for x,y in [(0.02,.02),(.5,.02),(.98,.02),(.02,.5),(.98,.5),(.02,.98),(.5,.98),(.98,.98)]]
    white = sum(1 for xy in points if (lambda p:p[3]<30 or min(p[:3])>235)(rgba.getpixel(xy))) / len(points)
    return im, data, white

def collect(i):
    target = ROOT / f'work/product-photo-{i}.json'
    if target.exists(): return json.loads(target.read_text())
    d = json.loads((ROOT / f'work/product-image-search-{i}.json').read_text())
    p = d['product']; candidates = sorted(d['candidates'], key=lambda c:score(p,c), reverse=True)
    options=[]; errors=[]
    for c in candidates[:7]:
        try:
            im, data, white = fetch(c)
            s = score(p,c) + 20*white
            options.append((s,im,data,white,c))
            if white == 1 and len(options)>=2: break
        except Exception as e: errors.append(str(e))
    if not options: return dict(index=i,product=p,error=errors)
    s,im,data,white,c = max(options,key=lambda x:x[0])
    slug = norm(p['brand']+' '+p['model']).replace(' ','-')
    filename = slug+'.webp'
    # Only format conversion and downscaling; preserve the source photograph.
    im.thumbnail((1200,1200), Image.Resampling.LANCZOS)
    if im.mode not in ('RGB','RGBA'): im=im.convert('RGBA' if 'transparency' in im.info else 'RGB')
    im.save(OUT/filename,'WEBP',quality=90,method=6)
    (RAW/(slug+'.source')).write_bytes(data)
    page = re.search(r'\((https?://[^\n]+)\)',c['text'].split('Image URL:')[0])
    result=dict(index=i,product=p,file='assets/products/'+filename,source_image=c['image'],source_page=page.group(1) if page else '',title=c['text'].split('\n')[0],white_border=white,match_score=score(p,c),size=im.size)
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
        for r in pool.map(collect,range(1,146)):
            print(json.dumps({k:r.get(k) for k in ['index','file','white_border','match_score','error']},ensure_ascii=False),flush=True)

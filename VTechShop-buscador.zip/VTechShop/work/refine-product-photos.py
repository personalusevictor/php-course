import sys, json, concurrent.futures, re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import importlib.util
spec=importlib.util.spec_from_file_location("photos",Path(__file__).with_name("collect-product-photos.py")); photos=importlib.util.module_from_spec(spec); spec.loader.exec_module(photos)
fetch=photos.fetch

OVERRIDES={7:0}
def run(pair):
 i,j=pair; path=photos.ROOT/f'work/product-photo-{i}.json'; r=json.loads(path.read_text()); c=json.loads((photos.ROOT/f'work/product-image-final-{i}.json').read_text())['candidates'][j]
 try:
  im,data,white=fetch(c); im.thumbnail((1200,1200),photos.Image.Resampling.LANCZOS)
  if im.mode not in ('RGB','RGBA'): im=im.convert('RGBA' if 'transparency' in im.info else 'RGB')
  im.save(photos.ROOT/r['file'],'WEBP',quality=90,method=6)
  page=re.search(r'\((https?://[^\n]+)\)',c['text'].split('Image URL:')[0]);r.update(source_image=c['image'],source_page=page.group(1) if page else '',title=c['text'].strip().split('\n')[0],white_border=white,size=im.size)
  path.write_text(json.dumps(r,ensure_ascii=False,indent=2));return i,'OK',white
 except Exception as e:return i,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for r in pool.map(run,OVERRIDES.items()):print(r,flush=True)
